# echo — React App

> Your digital second brain. Capture ideas, connect thoughts, discover patterns.

## Project structure

```
src/
├── styles/
│   ├── tokens.css          ← Design tokens (colors, spacing, type, radii)
│   └── global.css          ← Reset, base styles, animations
│
├── context/
│   └── EchoContext.jsx     ← Global state (ideas, tags, UI) via useReducer
│
├── hooks/
│   └── index.js            ← useReveal, useTypewriter, useDebounce,
│                               useLocalStorage, useScrolled, useKeyPress
│
├── utils/
│   └── index.js            ← formatDate, timeAgo, getTagColor,
│                               generateId, truncate, layoutNodes, cx
│
├── components/
│   ├── layout/
│   │   ├── Navbar.jsx       ← Fixed nav, scrolled blur, dashboard/landing modes
│   │   └── Navbar.module.css
│   │
│   ├── ui/
│   │   ├── Button.jsx       ← variant: primary | ghost | iris | danger
│   │   ├── Button.module.css
│   │   ├── Tag.jsx          ← Colored chip, clickable, removable
│   │   └── Tag.module.css
│   │
│   └── features/
│       ├── IdeaCard.jsx     ← Card with star, tags, connection count
│       ├── IdeaCard.module.css
│       ├── CaptureModal.jsx ← Cmd+K quick-add with typeahead tags
│       └── CaptureModal.module.css
│
├── pages/
│   ├── LandingPage.jsx      ← Hero + CTA (links to /dashboard)
│   ├── DashboardPage.jsx    ← 3-column: sidebar | idea list | detail
│   ├── DashboardPage.module.css
│   ├── GraphPage.jsx        ← SVG knowledge graph, click to explore
│   ├── GraphPage.module.css
│   └── NotFoundPage.jsx     ← 404
│
├── App.jsx                  ← Routes + EchoProvider wrapper
└── index.js                 ← ReactDOM.createRoot
```

## Getting started

```bash
npm install
npm start
```

## Key shortcuts

| Key    | Action              |
|--------|---------------------|
| Cmd+K  | Open capture modal  |
| Escape | Close modal         |
| Cmd+↵  | Save idea           |

## Color tokens (from tokens.css)

| Token        | Hex / Value         | Usage                        |
|--------------|---------------------|------------------------------|
| --void       | #080C10             | Page background              |
| --deep       | #0D1117             | Sidebar, section backgrounds |
| --card       | #1A2230             | Cards, modals                |
| --white      | #F0EFEB             | Primary text                 |
| --iris       | #8B7FD4             | Primary accent               |
| --aqua       | #4DADA0             | Connections, tags            |
| --gold       | #C9A84C             | Starred, highlights          |

## Next steps

1. **Connect to backend** — Wire addIdea / deleteIdea to your Express API (`POST /api/ideas`)
2. **Auth** — Add login/register pages, protect `/dashboard` and `/graph` routes
3. **Persistence** — Replace in-memory state with API calls + localStorage fallback
4. **Graph layout** — Swap layoutNodes() for a proper force-directed layout (d3-force)
5. **Search** — Add full-text search endpoint on the backend
6. **Deploy** — `npm run build` → deploy `/build` folder to Vercel / Netlify
