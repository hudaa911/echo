import { createContext, useContext, useReducer, useCallback } from 'react';

/* ── Initial state ── */
const initialState = {
  ideas: [
    {
      id: '1',
      title: 'On creative blocks and fear',
      body: 'Creativity doesn\'t disappear — it hides. The block is usually fear wearing the costume of writer\'s block.',
      tags: ['philosophy', 'creativity'],
      connections: ['2', '3'],
      starred: false,
      createdAt: new Date('2026-06-14').toISOString(),
    },
    {
      id: '2',
      title: 'The art of deep work',
      body: 'Focus is the new superpower. Undistracted concentration on cognitively demanding tasks produces outsized results.',
      tags: ['reading', 'productivity'],
      connections: ['1', '4'],
      starred: true,
      createdAt: new Date('2026-06-12').toISOString(),
    },
    {
      id: '3',
      title: 'Why constraints breed creativity',
      body: 'Limitations force you to think differently. The blank page is paradoxically harder than a constrained prompt.',
      tags: ['creativity', 'insight'],
      connections: ['1'],
      starred: false,
      createdAt: new Date('2026-06-10').toISOString(),
    },
    {
      id: '4',
      title: 'Notes on systems thinking',
      body: 'Everything is a system. Understanding feedback loops, stocks and flows changes how you see every problem.',
      tags: ['learning', 'systems'],
      connections: ['2'],
      starred: false,
      createdAt: new Date('2026-06-08').toISOString(),
    },
  ],

  tags: ['philosophy', 'creativity', 'reading', 'productivity', 'insight', 'learning', 'systems'],

  ui: {
    activeIdeaId: null,
    searchQuery: '',
    activeTag: null,
    sidebarOpen: true,
    captureOpen: false,
  },
};

/* ── Reducer ── */
function echoReducer(state, action) {
  switch (action.type) {

    case 'ADD_IDEA': {
      const newIdea = {
        id: Date.now().toString(),
        title: action.payload.title,
        body: action.payload.body || '',
        tags: action.payload.tags || [],
        connections: [],
        starred: false,
        createdAt: new Date().toISOString(),
      };
      // merge any new tags
      const mergedTags = [...new Set([...state.tags, ...newIdea.tags])];
      return {
        ...state,
        ideas: [newIdea, ...state.ideas],
        tags: mergedTags,
      };
    }

    case 'UPDATE_IDEA': {
      return {
        ...state,
        ideas: state.ideas.map(idea =>
          idea.id === action.payload.id
            ? { ...idea, ...action.payload }
            : idea
        ),
      };
    }

    case 'DELETE_IDEA': {
      return {
        ...state,
        ideas: state.ideas
          .filter(idea => idea.id !== action.payload)
          .map(idea => ({
            ...idea,
            connections: idea.connections.filter(c => c !== action.payload),
          })),
        ui: {
          ...state.ui,
          activeIdeaId:
            state.ui.activeIdeaId === action.payload ? null : state.ui.activeIdeaId,
        },
      };
    }

    case 'TOGGLE_STAR': {
      return {
        ...state,
        ideas: state.ideas.map(idea =>
          idea.id === action.payload
            ? { ...idea, starred: !idea.starred }
            : idea
        ),
      };
    }

    case 'CONNECT_IDEAS': {
      const { fromId, toId } = action.payload;
      return {
        ...state,
        ideas: state.ideas.map(idea => {
          if (idea.id === fromId && !idea.connections.includes(toId)) {
            return { ...idea, connections: [...idea.connections, toId] };
          }
          if (idea.id === toId && !idea.connections.includes(fromId)) {
            return { ...idea, connections: [...idea.connections, fromId] };
          }
          return idea;
        }),
      };
    }

    case 'SET_ACTIVE_IDEA':
      return { ...state, ui: { ...state.ui, activeIdeaId: action.payload } };

    case 'SET_SEARCH':
      return { ...state, ui: { ...state.ui, searchQuery: action.payload } };

    case 'SET_ACTIVE_TAG':
      return {
        ...state,
        ui: {
          ...state.ui,
          activeTag: state.ui.activeTag === action.payload ? null : action.payload,
        },
      };

    case 'TOGGLE_SIDEBAR':
      return { ...state, ui: { ...state.ui, sidebarOpen: !state.ui.sidebarOpen } };

    case 'TOGGLE_CAPTURE':
      return { ...state, ui: { ...state.ui, captureOpen: !state.ui.captureOpen } };

    default:
      return state;
  }
}

/* ── Context ── */
const EchoContext = createContext(null);

export function EchoProvider({ children }) {
  const [state, dispatch] = useReducer(echoReducer, initialState);

  /* Action creators */
  const addIdea     = useCallback((payload) => dispatch({ type: 'ADD_IDEA', payload }), []);
  const updateIdea  = useCallback((payload) => dispatch({ type: 'UPDATE_IDEA', payload }), []);
  const deleteIdea  = useCallback((id)      => dispatch({ type: 'DELETE_IDEA', payload: id }), []);
  const toggleStar  = useCallback((id)      => dispatch({ type: 'TOGGLE_STAR', payload: id }), []);
  const connectIdeas= useCallback((fromId, toId) => dispatch({ type: 'CONNECT_IDEAS', payload: { fromId, toId } }), []);
  const setActive   = useCallback((id)      => dispatch({ type: 'SET_ACTIVE_IDEA', payload: id }), []);
  const setSearch   = useCallback((q)       => dispatch({ type: 'SET_SEARCH', payload: q }), []);
  const setTag      = useCallback((tag)     => dispatch({ type: 'SET_ACTIVE_TAG', payload: tag }), []);
  const toggleSidebar  = useCallback(() => dispatch({ type: 'TOGGLE_SIDEBAR' }), []);
  const toggleCapture  = useCallback(() => dispatch({ type: 'TOGGLE_CAPTURE' }), []);

  /* Derived: filtered ideas */
  const filteredIdeas = state.ideas.filter(idea => {
    const q = state.ui.searchQuery.toLowerCase();
    const matchesSearch = !q ||
      idea.title.toLowerCase().includes(q) ||
      idea.body.toLowerCase().includes(q)  ||
      idea.tags.some(t => t.includes(q));
    const matchesTag = !state.ui.activeTag ||
      idea.tags.includes(state.ui.activeTag);
    return matchesSearch && matchesTag;
  });

  const activeIdea = state.ideas.find(i => i.id === state.ui.activeIdeaId) || null;

  return (
    <EchoContext.Provider value={{
      ...state,
      filteredIdeas,
      activeIdea,
      addIdea,
      updateIdea,
      deleteIdea,
      toggleStar,
      connectIdeas,
      setActive,
      setSearch,
      setTag,
      toggleSidebar,
      toggleCapture,
    }}>
      {children}
    </EchoContext.Provider>
  );
}

export function useEcho() {
  const ctx = useContext(EchoContext);
  if (!ctx) throw new Error('useEcho must be used inside <EchoProvider>');
  return ctx;
}
