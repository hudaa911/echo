import { useEffect, useRef, useState, useCallback } from 'react';

/* ─────────────────────────────────
   useReveal — IntersectionObserver scroll-in animation
   Usage: const { ref, visible } = useReveal();
   Then: <div ref={ref} className={visible ? 'visible' : ''}>
───────────────────────────────── */
export function useReveal(options = {}) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.unobserve(el);
        }
      },
      { threshold: 0.12, ...options }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return { ref, visible };
}

/* ─────────────────────────────────
   useTypewriter — cycles through phrases with typing effect
   Usage: const text = useTypewriter(['Hello', 'World'], { speed: 60 });
───────────────────────────────── */
export function useTypewriter(phrases = [], { speed = 60, deleteSpeed = 35, pauseMs = 1800 } = {}) {
  const [text, setText] = useState('');
  const [phraseIdx, setPhraseIdx] = useState(0);
  const [charIdx, setCharIdx] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    if (!phrases.length) return;
    const phrase = phrases[phraseIdx];

    const timeout = setTimeout(() => {
      if (!isDeleting) {
        const next = charIdx + 1;
        setText(phrase.slice(0, next));
        if (next === phrase.length) {
          setTimeout(() => setIsDeleting(true), pauseMs);
        } else {
          setCharIdx(next);
        }
      } else {
        const next = charIdx - 1;
        setText(phrase.slice(0, next));
        if (next === 0) {
          setIsDeleting(false);
          setPhraseIdx(i => (i + 1) % phrases.length);
          setCharIdx(0);
        } else {
          setCharIdx(next);
        }
      }
    }, isDeleting ? deleteSpeed : speed);

    return () => clearTimeout(timeout);
  }, [charIdx, isDeleting, phraseIdx, phrases, speed, deleteSpeed, pauseMs]);

  return text;
}

/* ─────────────────────────────────
   useDebounce — delay a value update
   Usage: const debounced = useDebounce(searchQuery, 300);
───────────────────────────────── */
export function useDebounce(value, delay = 300) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

/* ─────────────────────────────────
   useLocalStorage — persist state to localStorage
   Usage: const [val, setVal] = useLocalStorage('key', defaultVal);
───────────────────────────────── */
export function useLocalStorage(key, initial) {
  const [value, setValue] = useState(() => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : initial;
    } catch {
      return initial;
    }
  });

  const set = useCallback((v) => {
    try {
      const toStore = typeof v === 'function' ? v(value) : v;
      setValue(toStore);
      localStorage.setItem(key, JSON.stringify(toStore));
    } catch (e) {
      console.warn(`useLocalStorage: couldn't write key "${key}"`, e);
    }
  }, [key, value]);

  return [value, set];
}

/* ─────────────────────────────────
   useScrolled — tracks if page has scrolled past threshold
   Usage: const scrolled = useScrolled(20);
───────────────────────────────── */
export function useScrolled(threshold = 20) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > threshold);
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, [threshold]);
  return scrolled;
}

/* ─────────────────────────────────
   useKeyPress — listen for a specific key
   Usage: useKeyPress('k', handler, { meta: true }); // Cmd+K
───────────────────────────────── */
export function useKeyPress(key, handler, modifiers = {}) {
  useEffect(() => {
    const onKeyDown = (e) => {
      const metaOk  = !modifiers.meta  || (e.metaKey  || e.ctrlKey);
      const shiftOk = !modifiers.shift || e.shiftKey;
      if (e.key === key && metaOk && shiftOk) {
        e.preventDefault();
        handler(e);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [key, handler, modifiers]);
}
