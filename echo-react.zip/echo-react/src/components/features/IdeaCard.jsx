import { useEcho } from '../../context/EchoContext';
import Tag from '../ui/Tag';
import { timeAgo, truncate } from '../../utils';
import styles from './IdeaCard.module.css';

export default function IdeaCard({ idea }) {
  const { ui, setActive, toggleStar } = useEcho();
  const isActive = ui.activeIdeaId === idea.id;

  return (
    <article
      className={`${styles.card} ${isActive ? styles.active : ''}`}
      onClick={() => setActive(isActive ? null : idea.id)}
      aria-selected={isActive}
    >
      {/* Header */}
      <div className={styles.header}>
        <span className={styles.date}>{timeAgo(idea.createdAt)}</span>
        <button
          className={`${styles.star} ${idea.starred ? styles.starred : ''}`}
          onClick={(e) => { e.stopPropagation(); toggleStar(idea.id); }}
          aria-label={idea.starred ? 'Unstar idea' : 'Star idea'}
        >
          {idea.starred ? '✦' : '✧'}
        </button>
      </div>

      {/* Title */}
      <h3 className={styles.title}>{idea.title}</h3>

      {/* Body preview */}
      {idea.body && (
        <p className={styles.body}>{truncate(idea.body, 100)}</p>
      )}

      {/* Footer */}
      <div className={styles.footer}>
        <div className={styles.tags}>
          {idea.tags.slice(0, 3).map(tag => (
            <Tag key={tag} label={tag} />
          ))}
        </div>
        {idea.connections.length > 0 && (
          <span className={styles.connections}>
            ◈ {idea.connections.length}
          </span>
        )}
      </div>
    </article>
  );
}
