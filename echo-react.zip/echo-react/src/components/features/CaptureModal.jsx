import { useState, useEffect, useRef } from 'react';
import { useEcho } from '../../context/EchoContext';
import { useKeyPress } from '../../hooks';
import Button from '../ui/Button';
import Tag from '../ui/Tag';
import styles from './CaptureModal.module.css';

export default function CaptureModal() {
  const { ui, toggleCapture, addIdea, tags } = useEcho();
  const [title, setTitle]       = useState('');
  const [body, setBody]         = useState('');
  const [tagInput, setTagInput] = useState('');
  const [chosenTags, setChosenTags] = useState([]);
  const titleRef = useRef(null);

  // Focus title on open
  useEffect(() => {
    if (ui.captureOpen) {
      setTimeout(() => titleRef.current?.focus(), 50);
    } else {
      setTitle(''); setBody(''); setTagInput(''); setChosenTags([]);
    }
  }, [ui.captureOpen]);

  // Escape closes
  useKeyPress('Escape', () => { if (ui.captureOpen) toggleCapture(); });

  // Cmd+Enter submits
  useKeyPress('Enter', handleSubmit, { meta: true });

  function handleSubmit() {
    if (!title.trim()) { titleRef.current?.focus(); return; }
    addIdea({ title: title.trim(), body: body.trim(), tags: chosenTags });
    toggleCapture();
  }

  function handleTagKey(e) {
    if ((e.key === 'Enter' || e.key === ',') && tagInput.trim()) {
      e.preventDefault();
      const newTag = tagInput.trim().toLowerCase().replace(/\s+/g, '-');
      if (!chosenTags.includes(newTag)) setChosenTags(prev => [...prev, newTag]);
      setTagInput('');
    }
  }

  if (!ui.captureOpen) return null;

  return (
    <div className={styles.overlay} onClick={(e) => e.target === e.currentTarget && toggleCapture()}>
      <div className={styles.modal} role="dialog" aria-modal="true" aria-label="Capture new idea">

        <div className={styles.header}>
          <span className={styles.headerLabel}>✦ New idea</span>
          <button className={styles.close} onClick={toggleCapture} aria-label="Close">×</button>
        </div>

        {/* Title */}
        <input
          ref={titleRef}
          className={styles.titleInput}
          placeholder="What's the idea?"
          value={title}
          onChange={e => setTitle(e.target.value)}
          maxLength={120}
        />

        {/* Body */}
        <textarea
          className={styles.bodyInput}
          placeholder="Expand on it… (optional)"
          value={body}
          onChange={e => setBody(e.target.value)}
          rows={4}
        />

        {/* Tags */}
        <div className={styles.tagSection}>
          <div className={styles.chosenTags}>
            {chosenTags.map(t => (
              <Tag
                key={t}
                label={t}
                removable
                onRemove={(tag) => setChosenTags(prev => prev.filter(x => x !== tag))}
              />
            ))}
          </div>
          <input
            className={styles.tagInput}
            placeholder="Add tag, press Enter…"
            value={tagInput}
            onChange={e => setTagInput(e.target.value)}
            onKeyDown={handleTagKey}
          />
          {/* Suggestion chips */}
          <div className={styles.tagSuggestions}>
            {tags.filter(t => !chosenTags.includes(t)).slice(0, 6).map(t => (
              <button
                key={t}
                className={styles.tagSuggest}
                onClick={() => setChosenTags(prev => [...prev, t])}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className={styles.actions}>
          <Button variant="ghost" size="sm" onClick={toggleCapture}>Cancel</Button>
          <Button variant="primary" size="sm" onClick={handleSubmit} disabled={!title.trim()}>
            Save idea
            <span className={styles.shortcut}>⌘↵</span>
          </Button>
        </div>

      </div>
    </div>
  );
}
