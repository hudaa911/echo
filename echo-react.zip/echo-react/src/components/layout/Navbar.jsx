import { Link, useLocation } from 'react-router-dom';
import { useScrolled } from '../../hooks';
import { useEcho } from '../../context/EchoContext';
import styles from './Navbar.module.css';

export default function Navbar() {
  const scrolled   = useScrolled(20);
  const location   = useLocation();
  const { toggleCapture } = useEcho();
  const isDashboard = location.pathname !== '/';

  return (
    <nav className={`${styles.nav} ${scrolled ? styles.scrolled : ''}`} aria-label="Main navigation">
      <div className={styles.inner}>
        {/* Logo */}
        <Link to="/" className={styles.logo} aria-label="Echo home">
          echo<span className={styles.logoDot}>·</span>
        </Link>

        {/* Links */}
        <ul className={styles.links}>
          {isDashboard ? (
            <>
              <li><Link to="/dashboard" className={styles.link}>Ideas</Link></li>
              <li><Link to="/graph"     className={styles.link}>Graph</Link></li>
            </>
          ) : (
            <>
              <li><a href="#how"      className={styles.link}>How it works</a></li>
              <li><a href="#features" className={styles.link}>Features</a></li>
              <li><a href="#tech"     className={styles.link}>Tech</a></li>
              <li>
                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className={styles.link}
                >
                  GitHub ↗
                </a>
              </li>
            </>
          )}
        </ul>

        {/* Actions */}
        <div className={styles.actions}>
          {isDashboard ? (
            <button className={styles.btnPrimary} onClick={toggleCapture}>
              + Capture
            </button>
          ) : (
            <>
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className={styles.btnGhost}
              >
                View repo
              </a>
              <Link to="/dashboard" className={styles.btnPrimary}>
                Try Echo
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
