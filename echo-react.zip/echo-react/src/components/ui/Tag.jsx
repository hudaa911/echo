import { getTagColor } from '../../utils';
import styles from './Tag.module.css';

export default function Tag({ label, onClick, active = false, removable = false, onRemove }) {
  const color = getTagColor(label);

  return (
    <span
      className={`${styles.tag} ${active ? styles.active : ''} ${onClick ? styles.clickable : ''}`}
      style={{ '--tag-bg': color.bg, '--tag-text': color.text }}
      onClick={onClick}
    >
      {label}
      {removable && (
        <button
          className={styles.remove}
          onClick={(e) => { e.stopPropagation(); onRemove?.(label); }}
          aria-label={`Remove tag ${label}`}
        >
          ×
        </button>
      )}
    </span>
  );
}
