import { Routes, Route } from 'react-router-dom';
import { EchoProvider } from './context/EchoContext';
import LandingPage from './pages/LandingPage';
import DashboardPage from './pages/DashboardPage';
import GraphPage from './pages/GraphPage';
import NotFoundPage from './pages/NotFoundPage';

export default function App() {
  return (
    <EchoProvider>
      <Routes>
        <Route path="/"          element={<LandingPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/graph"     element={<GraphPage />} />
        <Route path="*"          element={<NotFoundPage />} />
      </Routes>
    </EchoProvider>
  );
}
