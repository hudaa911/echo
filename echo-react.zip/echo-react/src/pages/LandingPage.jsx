// LandingPage.jsx
// This page uses the static index.html you already built.
// In the React app, this component re-implements the same
// sections as JSX. For now it redirects to the static page
// or you can copy the HTML sections in here as JSX.

import { Link } from 'react-router-dom';
import Navbar from '../components/layout/Navbar';

export default function LandingPage() {
  return (
    <>
      <Navbar />
      <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '2rem', textAlign: 'center' }}>
        <div style={{ fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--iris)', marginBottom: 16 }}>
          Your digital second brain
        </div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(40px, 7vw, 72px)', fontWeight: 400, letterSpacing: '-0.02em', lineHeight: 1.15, marginBottom: 20, color: 'var(--white)' }}>
          Think deeper.<br />
          Connect <em style={{ color: 'var(--iris-hi)', fontStyle: 'italic' }}>everything.</em>
        </h1>
        <p style={{ fontSize: 17, fontWeight: 300, color: 'var(--white-45)', maxWidth: 440, lineHeight: 1.75, marginBottom: 36 }}>
          Echo links your ideas, notes, and inspirations into a living knowledge network — not just a folder.
        </p>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', justifyContent: 'center' }}>
          <Link to="/dashboard" style={{ background: 'var(--white)', color: 'var(--void)', padding: '12px 26px', borderRadius: 'var(--r-md)', fontSize: 14, fontWeight: 500 }}>
            Open dashboard →
          </Link>
          <Link to="/graph" style={{ background: 'var(--iris-lo)', color: 'var(--iris-hi)', border: '0.5px solid rgba(139,127,212,0.2)', padding: '12px 26px', borderRadius: 'var(--r-md)', fontSize: 14 }}>
            View knowledge graph
          </Link>
        </div>
      </main>
    </>
  );
}
