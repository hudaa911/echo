import { useEcho } from '../context/EchoContext';
import { useKeyPress } from '../hooks';
import Navbar from '../components/layout/Navbar';
import IdeaCard from '../components/features/IdeaCard';
import CaptureModal from '../components/features/CaptureModal';
import Button from '../components/ui/Button';
import Tag from '../components/ui/Tag';
import { formatDate, timeAgo } from '../utils';
import styles from './DashboardPage.module.css';

export default function DashboardPage() {
  const {
    filteredIdeas, ideas, activeIdea, tags,
    ui, setSearch, setTag, toggleCapture, toggleStar, deleteIdea,
  } = useEcho();

  // Cmd+K opens capture
  useKeyPress('k', toggleCapture, { meta: true });

  return (
    <div className={styles.layout}>
      <Navbar />
      <CaptureModal />

      {/* ── Sidebar ── */}
      <aside className={styles.sidebar}>
        <div className={styles.sidebarTop}>
          <span className={styles.sidebarLogo}>echo<span>·</span></span>
          <button className={styles.captureBtn} onClick={toggleCapture}>
            + Capture
            <kbd className={styles.kbd}>⌘K</kbd>
          </button>
        </div>

        {/* Search */}
        <div className={styles.searchWrap}>
          <span className={styles.searchIcon}>⌕</span>
          <input
            className={styles.search}
            placeholder="Search ideas…"
            value={ui.searchQuery}
            onChange={e => setSearch(e.target.value)}
            aria-label="Search ideas"
          />
        </div>

        {/* Tags */}
        <div className={styles.tagSection}>
          <div className={styles.tagLabel}>Topics</div>
          <div className={styles.tagList}>
            {tags.map(tag => (
              <Tag
                key={tag}
                label={tag}
                active={ui.activeTag === tag}
                onClick={() => setTag(tag)}
                clickable
              />
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className={styles.sidebarStats}>
          <div className={styles.statRow}>
            <span className={styles.statN}>{ideas.length}</span>
            <span className={styles.statL}>ideas</span>
          </div>
          <div className={styles.statRow}>
            <span className={styles.statN}>{ideas.reduce((a, i) => a + i.connections.length, 0)}</span>
            <span className={styles.statL}>connections</span>
          </div>
          <div className={styles.statRow}>
            <span className={styles.statN}>{ideas.filter(i => i.starred).length}</span>
            <span className={styles.statL}>starred</span>
          </div>
        </div>
      </aside>

      {/* ── Main: Idea list ── */}
      <main className={styles.main}>
        <div className={styles.mainHeader}>
          <h1 className={styles.mainTitle}>
            {ui.activeTag ? `#${ui.activeTag}` : ui.searchQuery ? 'Results' : 'All ideas'}
          </h1>
          <span className={styles.mainCount}>{filteredIdeas.length}</span>
        </div>

        {filteredIdeas.length === 0 ? (
          <div className={styles.empty}>
            <div className={styles.emptyIcon}>✦</div>
            <p className={styles.emptyTitle}>Nothing here yet</p>
            <p className={styles.emptySub}>
              {ui.searchQuery ? 'Try a different search' : 'Capture your first idea'}
            </p>
            {!ui.searchQuery && (
              <Button variant="iris" size="sm" onClick={toggleCapture}>
                + Capture idea
              </Button>
            )}
          </div>
        ) : (
          <div className={styles.ideaGrid}>
            {filteredIdeas.map(idea => (
              <IdeaCard key={idea.id} idea={idea} />
            ))}
          </div>
        )}
      </main>

      {/* ── Detail panel ── */}
      <aside className={`${styles.detail} ${activeIdea ? styles.detailOpen : ''}`}>
        {activeIdea ? (
          <>
            <div className={styles.detailHeader}>
              <button
                className={`${styles.detailStar} ${activeIdea.starred ? styles.detailStarred : ''}`}
                onClick={() => toggleStar(activeIdea.id)}
                aria-label="Toggle star"
              >
                {activeIdea.starred ? '✦' : '✧'}
              </button>
              <button
                className={styles.detailDelete}
                onClick={() => deleteIdea(activeIdea.id)}
                aria-label="Delete idea"
              >
                ✕
              </button>
            </div>

            <h2 className={styles.detailTitle}>{activeIdea.title}</h2>
            <p className={styles.detailDate}>{formatDate(activeIdea.createdAt)}</p>

            {activeIdea.body && (
              <p className={styles.detailBody}>{activeIdea.body}</p>
            )}

            <div className={styles.detailTags}>
              {activeIdea.tags.map(t => <Tag key={t} label={t} />)}
            </div>

            {activeIdea.connections.length > 0 && (
              <div className={styles.connections}>
                <div className={styles.connectLabel}>◈ Connected ideas</div>
                {activeIdea.connections.map(cid => {
                  const connected = ideas.find(i => i.id === cid);
                  if (!connected) return null;
                  return (
                    <div key={cid} className={styles.connectionChip}>
                      <span className={styles.connectionDot} />
                      {connected.title}
                    </div>
                  );
                })}
              </div>
            )}
          </>
        ) : (
          <div className={styles.detailEmpty}>
            <div className={styles.detailEmptyIcon}>◈</div>
            <p>Select an idea to explore it</p>
          </div>
        )}
      </aside>
    </div>
  );
}
