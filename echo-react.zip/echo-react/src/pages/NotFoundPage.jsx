import { Link } from 'react-router-dom';

export default function NotFoundPage() {
  return (
    <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: '2rem' }}>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 80, color: 'var(--white-10)', lineHeight: 1, marginBottom: 24 }}>404</div>
      <h1 style={{ fontSize: 20, fontWeight: 500, color: 'var(--white)', marginBottom: 10 }}>Page not found</h1>
      <p style={{ fontSize: 14, color: 'var(--white-45)', marginBottom: 28 }}>This idea doesn't exist in your network yet.</p>
      <Link to="/" style={{ background: 'var(--iris-lo)', color: 'var(--iris-hi)', border: '0.5px solid rgba(139,127,212,0.2)', padding: '10px 20px', borderRadius: 'var(--r-md)', fontSize: 14 }}>
        ← Back to Echo
      </Link>
    </main>
  );
}
