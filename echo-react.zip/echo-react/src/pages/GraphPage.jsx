import { useState, useRef, useEffect } from 'react';
import { useEcho } from '../context/EchoContext';
import Navbar from '../components/layout/Navbar';
import CaptureModal from '../components/features/CaptureModal';
import { layoutNodes, truncate } from '../utils';
import styles from './GraphPage.module.css';

export default function GraphPage() {
  const { ideas, setActive, activeIdea } = useEcho();
  const svgRef = useRef(null);
  const [dimensions, setDimensions] = useState({ w: 800, h: 600 });
  const [hoveredId, setHoveredId] = useState(null);

  // Responsive SVG dimensions
  useEffect(() => {
    const update = () => {
      if (svgRef.current) {
        const rect = svgRef.current.getBoundingClientRect();
        setDimensions({ w: rect.width, h: rect.height });
      }
    };
    update();
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, []);

  const cx = dimensions.w / 2;
  const cy = dimensions.h / 2;
  const nodes = layoutNodes(ideas).map(n => ({ ...n, x: n.x + cx, y: n.y + cy }));
  const nodeMap = Object.fromEntries(nodes.map(n => [n.id, n]));

  return (
    <div className={styles.page}>
      <Navbar />
      <CaptureModal />

      <div className={styles.header}>
        <h1 className={styles.title}>Knowledge graph</h1>
        <p className={styles.sub}>{ideas.length} ideas · {ideas.reduce((a, i) => a + i.connections.length, 0)} connections</p>
      </div>

      <div className={styles.canvas} ref={svgRef}>
        <svg width="100%" height="100%" aria-label="Knowledge graph of your ideas">

          {/* Edges */}
          {ideas.map(idea =>
            idea.connections.map(connId => {
              const from = nodeMap[idea.id];
              const to   = nodeMap[connId];
              if (!from || !to) return null;
              const isHighlighted =
                hoveredId === idea.id || hoveredId === connId ||
                activeIdea?.id === idea.id || activeIdea?.id === connId;
              return (
                <line
                  key={`${idea.id}-${connId}`}
                  x1={from.x} y1={from.y}
                  x2={to.x}   y2={to.y}
                  stroke={isHighlighted ? 'var(--iris)' : 'var(--border-hi)'}
                  strokeWidth={isHighlighted ? 1.5 : 0.8}
                  opacity={isHighlighted ? 0.6 : 0.3}
                  style={{ transition: 'all 0.25s ease' }}
                />
              );
            })
          )}

          {/* Nodes */}
          {nodes.map(node => {
            const idea = ideas.find(i => i.id === node.id);
            const isActive  = activeIdea?.id === node.id;
            const isHovered = hoveredId === node.id;
            const isConnected = activeIdea?.connections?.includes(node.id);
            const r = node.size + (isActive || isHovered ? 3 : 0);

            return (
              <g
                key={node.id}
                onClick={() => setActive(isActive ? null : node.id)}
                onMouseEnter={() => setHoveredId(node.id)}
                onMouseLeave={() => setHoveredId(null)}
                style={{ cursor: 'pointer' }}
                role="button"
                aria-label={idea?.title}
              >
                {/* Glow ring for active */}
                {(isActive || isHovered) && (
                  <circle
                    cx={node.x} cy={node.y} r={r + 6}
                    fill="none"
                    stroke={node.starred ? 'var(--gold)' : 'var(--iris)'}
                    strokeWidth="0.8"
                    opacity="0.3"
                  />
                )}
                {isConnected && (
                  <circle
                    cx={node.x} cy={node.y} r={r + 4}
                    fill="none"
                    stroke="var(--aqua)"
                    strokeWidth="0.8"
                    opacity="0.4"
                  />
                )}

                {/* Node circle */}
                <circle
                  cx={node.x} cy={node.y} r={r}
                  fill={
                    isActive    ? 'var(--iris)' :
                    isConnected ? 'var(--aqua)' :
                    node.starred ? 'var(--gold)' :
                    'var(--card-hi)'
                  }
                  stroke={
                    isActive    ? 'var(--iris-hi)' :
                    isConnected ? 'var(--aqua)' :
                    'var(--border-hi)'
                  }
                  strokeWidth="0.8"
                  style={{ transition: 'all 0.25s ease' }}
                />

                {/* Label */}
                {(isActive || isHovered || isConnected || node.size >= 9) && (
                  <text
                    x={node.x}
                    y={node.y + r + 14}
                    textAnchor="middle"
                    fontSize="11"
                    fontFamily="Inter, sans-serif"
                    fill={isActive ? 'var(--iris-hi)' : 'var(--white-45)'}
                    style={{ pointerEvents: 'none', transition: 'fill 0.2s' }}
                  >
                    {truncate(node.label, 24)}
                  </text>
                )}
              </g>
            );
          })}
        </svg>

        {/* Floating detail card */}
        {activeIdea && (
          <div className={styles.floatCard}>
            <div className={styles.floatTitle}>{activeIdea.title}</div>
            {activeIdea.body && (
              <p className={styles.floatBody}>{truncate(activeIdea.body, 80)}</p>
            )}
            <div className={styles.floatMeta}>
              ◈ {activeIdea.connections.length} connections
            </div>
          </div>
        )}

        {/* Legend */}
        <div className={styles.legend}>
          <div className={styles.legendItem}>
            <span className={styles.legendDot} style={{ background: 'var(--iris)' }} />
            Selected
          </div>
          <div className={styles.legendItem}>
            <span className={styles.legendDot} style={{ background: 'var(--aqua)' }} />
            Connected
          </div>
          <div className={styles.legendItem}>
            <span className={styles.legendDot} style={{ background: 'var(--gold)' }} />
            Starred
          </div>
        </div>
      </div>
    </div>
  );
}
