/* ── Date formatting ── */
export function formatDate(isoString) {
  const date = new Date(isoString);
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function timeAgo(isoString) {
  const diff = Date.now() - new Date(isoString).getTime();
  const mins  = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days  = Math.floor(diff / 86400000);
  if (mins  < 1)  return 'just now';
  if (mins  < 60) return `${mins}m ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days  < 7)  return `${days}d ago`;
  return formatDate(isoString);
}

/* ── Tag color mapping ── */
const TAG_PALETTE = [
  { bg: 'var(--iris-lo)',  text: 'var(--iris-hi)' },
  { bg: 'var(--aqua-lo)', text: 'var(--aqua)' },
  { bg: 'var(--gold-lo)', text: 'var(--gold)' },
];

const tagColorCache = {};

export function getTagColor(tag) {
  if (!tagColorCache[tag]) {
    const hash = [...tag].reduce((acc, c) => acc + c.charCodeAt(0), 0);
    tagColorCache[tag] = TAG_PALETTE[hash % TAG_PALETTE.length];
  }
  return tagColorCache[tag];
}

/* ── ID generation ── */
export function generateId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

/* ── Text helpers ── */
export function truncate(str, maxLen = 120) {
  if (!str || str.length <= maxLen) return str;
  return str.slice(0, maxLen).trimEnd() + '…';
}

export function extractWords(text, count = 10) {
  return text.split(/\s+/).slice(0, count).join(' ');
}

/* ── Graph layout — simple force positions for SVG ── */
export function layoutNodes(ideas) {
  const cx = 0, cy = 0;
  return ideas.map((idea, i) => {
    const angle = (2 * Math.PI * i) / ideas.length - Math.PI / 2;
    const radius = ideas.length === 1 ? 0 : 120 + Math.random() * 40;
    return {
      id: idea.id,
      label: extractWords(idea.title, 3),
      x: cx + radius * Math.cos(angle),
      y: cy + radius * Math.sin(angle),
      size: 6 + idea.connections.length * 2,
      starred: idea.starred,
    };
  });
}

/* ── Class name helper (minimal clsx-like) ── */
export function cx(...args) {
  return args.filter(Boolean).join(' ');
}
